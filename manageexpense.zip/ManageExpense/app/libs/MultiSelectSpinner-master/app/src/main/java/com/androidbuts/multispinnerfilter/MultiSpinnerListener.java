package com.androidbuts.multispinnerfilter;

public interface MultiSpinnerListener {
    void onItemsSelected(boolean[] selected);
}