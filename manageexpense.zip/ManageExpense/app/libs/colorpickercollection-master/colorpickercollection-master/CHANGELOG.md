Change Log
==========

Version 1.1.0 *(2013-09-03)*
----------------------------

 * New custom **`ColorPickerPreference`** based on ColorPicker (Stock Calendar)
 * Switched PreferenceActivity to PreferenceFragment  
 * Fixed a issue with listener in `MainActivity`
 
 
 Version 1.0.0 *(2013-08-22)*
----------------------------

Initial release.
